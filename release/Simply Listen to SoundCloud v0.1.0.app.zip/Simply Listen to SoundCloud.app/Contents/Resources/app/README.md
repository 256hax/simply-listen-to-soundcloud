# simply-listen-to-soundcloud

Just linsten to SoundCloud PC version (like IFrame) on Mac.
Use Webview method in Electron.
